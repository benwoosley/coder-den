<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forum</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <header>
        <h1>Coder's Den</h1>
    </header>
    <script src="http://code.jquery.com/jquery-3.1.0.min.js"></script>
    <script>
        $(function () {
            $("#nav").hide();
            $("#menuBtn").on("click", function () {
                $("#nav").slideDown(500);
            });
            $("#menuBtn").on("dblclick", function () {
                $("#nav").slideUp(300);
            });
        });
    </script>
    <button id="menuBtn">Menu</button>
    <ul id="nav">
        <li><a href="CS316Project5.html"> Main Forum </a></li>
        <li><a href="Accounts/login.html"> Login </a></li>
        <li><a href="Accounts/signup.html"> Sign Up </a></li>
        <li><a href="Posts/posts.php"> Questions </a></li>
        <li><a href="aboutus.html"> About Us </a></li>
        <li><a href="contactus.html"> Contact Us </a></li>
    </ul>
    <div class="imageheader">
        <img src="images/forum.jpg" alt="Main Forum">
    </div>
    <div class="container">
        <div class="column1">
            <h2>Forum Details</h2>
            <div class="columncontent">
                <p>This forum is to share your experiences with programming and the goal is to educate all who read
                    the discussions. </p>
            </div>
        </div>
        <div class="column1">
            <h2>Questions</h2>
            <div class="columncontent">
                <ol>
                    <li>
                        <a href="Posts/question.html">
                            <h3>Why is the tree on the right wrong?</h3>
                        </a>
                        <figure class="thumbnail">
                            <img src="images/problem1.jpeg" alt="thumbnail">
                            <figcaption class="popup">
                                <a href="#">
                                    <img src="images/problem1.jpeg" alt="thumbnail">
                                    <p>Full Image</p>
                                </a>
                            </figcaption>
                        </figure>
                        <p>tags: bst</p>
                        <p>Answers: 7</p>
                        <a href="Accounts/account.html">
                            <h4>John Smith</h4>
                        </a>
                    </li>
                    <li>
                        <a href="Posts/question.html">
                            <h3>How do you compute this double integral?</h3>
                        </a>
                        <figure class="thumbnail">
                            <img src="images/problem2.jpeg" alt="thumbnail">
                            <figcaption class="popup">
                                <a href="#">
                                    <img src="images/problem2.jpeg" alt="thumbnail">
                                    <p>Full Image</p>
                                </a>
                            </figcaption>
                        </figure>
                        <p>tags: calculus</p>
                        <p>Answers: 0</p>
                        <a href="Accounts/account.html">
                            <h4>John Doe</h4>
                        </a>
                    </li>
                    <li>
                        <a href="Posts/question.html">
                            <h3>What does this error mean?</h3>
                        </a>
                        <figure class="thumbnail">
                            <img src="images/problem3.jpeg" alt="thumbnail">
                            <figcaption class="popup">
                                <a href="#">
                                    <img src="images/problem3.jpeg" alt="thumbnail">
                                    <p>Full Image</p>
                                </a>
                            </figcaption>
                        </figure>
                        <p>tags: unix</p>
                        <p>Answers: 0</p>
                        <a href="Accounts/account.html">
                            <h4>John Cena</h4>
                        </a>
                    </li>
                </ol>
            </div>
        </div>
        <div class="column1">
            <h2>Top Askers</h2>
            <div class="columncontent">
                <div class="user">
                    <a href="#">
                        <h3>John Smith</h3>
                        <p>Data Structures</p>
                    </a>
                </div>
                <div class="user">
                    <a href="#">
                        <h3>John Doe</h3>
                        <p>Calculus</p>
                    </a>
                </div>
                <div class="user">
                    <a href="#">
                        <h3>John Cena</h3>
                        <p>Signals</p>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div class="questioncontainer">
        <div class="column1">
            <h2>Customization</h2>
            <div class="columncontent">
                <button id="dark-mode-toggle" class="dark-mode-toggle">Light/Dark</button>
                <br>
                <p> and choose your accent color...</p>
                <input type="color" class="colorInput" id="colorInput">
                <br>
                <button id="colorButton" onclick="changeColor()">Click to apply.</button>
                <br>
            </div>
        </div>
    </div>
    <script src="./js/darkmode.js"></script>
    <script src="./js/colorchange.js"></script>
</body>

</html>
