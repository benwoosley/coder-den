<?php

$conn = new mysqli('localhost', 'projec6', 'password', 'posts');

if(!$conn){
  echo "failed to connect" . $conn -> connect_error;
}


$email = $_POST["email"];
$content = $_POST["content"];
$sql = "INSERT INTO posts(email, content) VALUES('$email', '$content')";

$result = mysqli_query($conn, $sql);

if($result){
  echo "Post inserted";
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forum</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <script src="../js/darkmode.js" async></script>
    <script src="../js/colorchange.js" async></script>
</head>

<body>
    <header>
        <h1>Coder's Den</h1>
    </header>
    <script src="http://code.jquery.com/jquery-3.1.0.min.js"></script>
    <script>
    $(function () {
    $("#nav").hide();
    $("#menuBtn").on("click", function () {
       $("#nav").slideDown(500);
    });
    $("#menuBtn").on("dblclick", function () {
       $("#nav").slideUp(300);
    });
});
    </script>
    <button id="menuBtn">Menu</button>
    <ul id="nav">
      <li><a href="../CS316Project5.html"> Main Forum </a></li>
      <li><a href="../Accounts/login.html"> Login </a></li>
      <li><a href="../Accounts/signup.html"> Sign Up </a></li>
      <li><a href="main.html"> Questions </a></li>
      <li><a href="../aboutus.html"> About Us </a></li>
      <li><a href="../contactus.html"> Contact Us </a></li>
    </ul>
        <div class="column1">
            <h2>Your Answer</h2>
            <div class="columncontent">
                <form action="posts.php" method="POST">
                <p> Email </p>
                <input type = "text" name = "email">
                    <div class="answer">
                        <textarea rows="10" name="content"></textarea>
                        <input type="submit" name="Submit">
                        <input type="reset" value="Reset">
                    </div>
                  </div>
                </form>

            </div>
        </div>
</body>

</html>
